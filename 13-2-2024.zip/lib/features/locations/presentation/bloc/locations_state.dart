import 'package:flutter/material.dart';

@immutable
abstract class LocationsState{
  const LocationsState();
}
class LocationsInitialState extends LocationsState {}

class LocationsSuccessfullyState extends LocationsState{
  const LocationsSuccessfullyState();
}

class AddLocationSuccessfullyState extends LocationsState{
  const AddLocationSuccessfullyState();
}

class UpdateCurrentLocationSuccessfullyState extends LocationsState{
  const UpdateCurrentLocationSuccessfullyState();
}


class LocationsFailedState extends LocationsState{
  const LocationsFailedState();
}

class LocationsLoadingState extends LocationsState{
  const LocationsLoadingState();
}



class UpdateCurrentShippingLoadingState extends LocationsState{
  const UpdateCurrentShippingLoadingState();
}
class UpdateCurrentShippingSuccessfullyState extends LocationsState{
  const UpdateCurrentShippingSuccessfullyState();
}